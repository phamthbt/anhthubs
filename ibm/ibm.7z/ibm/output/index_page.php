<?php
namespace Ibm;

class Foo{
	public function  say(){
		
		echo 'name foo';
	}
}
?>